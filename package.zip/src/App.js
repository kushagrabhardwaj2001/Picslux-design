import React from 'react';
import Design from './Components/Design';

function App() {
  return (
   <div>
<Design/>
   </div>
  );
}

export default App;
